#ifndef __in
#define __in
#include<bits/stdc++.h>
using namespace std;
namespace work
{

class Inquiry
{
public:
    Inquiry();
    void getBalanceDetails(Bank &);
};

}
#endif
